<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author super_ZED <funing@renrentou.com>
 */
$lang['themes_url']            = '通过url地址下载这些js主题';
$lang['be_repo']               = '通过你的网站下载主题';
