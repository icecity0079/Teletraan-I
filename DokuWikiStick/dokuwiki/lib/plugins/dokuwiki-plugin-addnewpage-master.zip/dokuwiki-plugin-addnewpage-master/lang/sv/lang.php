<?php

/*
 * Swedish language file
 * Save file as UTF8.
 */
$lang['namespaceRoot'] = "Rot";
$lang['okbutton']      = "Skapa sida";
$lang['nooption']      = "Du har inte behörighet att skapa sidor";
