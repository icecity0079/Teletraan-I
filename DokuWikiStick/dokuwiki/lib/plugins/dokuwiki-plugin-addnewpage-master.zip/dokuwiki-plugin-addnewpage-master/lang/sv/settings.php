<?php
/*USE : UTF8*/

/*
 * Swedish language file
 */
$lang['addpage_exclude']  = "Exkluderade namnrymder (separera med ;)";
$lang['addpage_showroot'] = "Visa rotrymd";
$lang['addpage_hide']     = "När du använder {{NEWPAGE>[ns]}} syntax: Dölj val av namnrymd (ej ikryssad: visa bara undernamnrymder)";
$lang['addpage_hideACL']  = "Dölj {{NEWPAGE}} om användaren inte har rättighet att skapa sidor (visa meddelande om ej ikryssad)";
