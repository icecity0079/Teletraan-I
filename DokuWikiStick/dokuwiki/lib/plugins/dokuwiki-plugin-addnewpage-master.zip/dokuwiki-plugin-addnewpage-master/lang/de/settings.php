<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 */
$lang['addpage_exclude']       = 'Namespaces ausschließen (getrennt mit ; )';
$lang['addpage_showroot']      = 'Wurzel-Namespace anzeigen';
$lang['addpage_hide']          = '{{NEWPAGE>[ns]}} Syntax: Ausgewählt, diese Namespace-Selektion verbergen. Nicht ausgewählt, nur diese Namespace-Selektion anzeigen.';
$lang['addpage_hideACL']       = 'Wenn ein Benutzer keine Berechtigung hat: Ausgewählt, Anzeige wird verborgen. Nicht ausgewählt, Es wird eine Fehlermeldung ausgegeben.';
