<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Michael <michael@krmr.org>
 */
$lang['namespaceRoot']         = ':Wurzel';
$lang['okbutton']              = 'Seite hinzufügen';
$lang['nooption']              = 'Du besitzt nicht die Benutzerrechte um Seiten hinzuzufügen.';
