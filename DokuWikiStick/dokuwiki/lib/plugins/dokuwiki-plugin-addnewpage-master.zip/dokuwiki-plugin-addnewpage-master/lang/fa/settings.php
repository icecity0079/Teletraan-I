<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Sam01 <m.sajad079@gmail.com>
 */
$lang['addpage_exclude']       = 'حذف فضاهای نام (جدا کردن از هم با ;)';
$lang['addpage_showroot']      = 'نمایش فضای‌نام ریشه';
$lang['addpage_hide']          = 'زمانی که استفاده می‌کنید از {{NEWPAGE>[ns]}} نحو: مخفی سازی فضای‌نام انتخابی
(تیک: نمایش تمام فضاهای زیر نام)';
$lang['addpage_hideACL']       = 'مخفی کردن {{NEWPAGE}} اگر کاربران';
