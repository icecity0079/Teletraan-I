<?php
/*USE : UTF8*/

/*
 * English language file
 */
$lang['addpage_exclude']  = "Excluded namespaces (separated with ;)";
$lang['addpage_showroot'] = "Show root namespace";
$lang['addpage_hide']     = "When you use {{NEWPAGE>[ns]}} syntax: Hide namespace selection (unchecked: show only subnamespaces)";
$lang['addpage_hideACL']  = "Hide {{NEWPAGE}} if user does not have rights to add pages (show message if unchecked)";
