<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Jaroslav Lichtblau <jlichtblau@seznam.cz>
 */
$lang['addpage_exclude']       = 'Vyloučit jmenné prostory (oddělené středníkem ;)';
$lang['addpage_showroot']      = 'Zobrazit kořenový jmenný prostor';
$lang['addpage_hide']          = 'Pokud použijete {{NEWPAGE>[ns]}} syntax: Skrýt výběr jmenného prostoru (nezaškrtnuto: zobrazit pouze jmenné podprostory)';
$lang['addpage_hideACL']       = 'Skrýt {{NEWPAGE}} pokud uživatel nemá práva pro přidávání stránek (nezaškrtnuto: zobrazit zprávu)';
