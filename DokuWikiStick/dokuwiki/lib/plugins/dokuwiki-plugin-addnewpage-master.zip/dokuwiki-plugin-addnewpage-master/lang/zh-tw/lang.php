<?php
/*
Traditional Chinese language file
 */
$lang['namespaceRoot']="最上層(Root)";
$lang['okbutton']     ="新增頁面";
$lang['nooption']     ="你沒有權限執行新增頁面的動作";
//Setup VIM: ex: et ts=2 enc=utf-8 :
