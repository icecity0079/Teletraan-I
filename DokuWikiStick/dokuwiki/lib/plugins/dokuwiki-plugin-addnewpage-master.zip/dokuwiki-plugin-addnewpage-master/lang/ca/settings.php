<?php
/*USE : UTF8*/

/*
 * Catalan language file
 */
$lang['addpage_exclude']  = "espais de nom a excloure (separats par un ;)";
$lang['addpage_showroot'] = "Mostrar l'espai de nom arrel";
$lang['addpage_hide']     = "Quan feu servir la sintaxi {{NEWPAGE>[ns]}}: Oculta la selecció d'espais de nom (desmarcat: només mostra els subespais de nom)";
$lang['addpage_hideACL']  = "Si desmarcat, mostra un missatge quan l'usuari no té permisos suficients per crear una pàgina. Si no, occulta {{NEWPAGE}}";
