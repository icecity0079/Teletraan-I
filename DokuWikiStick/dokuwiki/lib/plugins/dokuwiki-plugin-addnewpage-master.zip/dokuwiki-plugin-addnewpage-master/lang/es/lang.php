<?php
/*
 * Spanish language file (Paraguay)
 */
$lang['namespaceRoot'] = "Raiz";
$lang['okbutton']      = "Agregar pagina";
$lang['nooption']      = "Ud. no tiene privilegios para crear la pagina";
//Setup VIM: ex: et ts=2 enc=utf-8 :
