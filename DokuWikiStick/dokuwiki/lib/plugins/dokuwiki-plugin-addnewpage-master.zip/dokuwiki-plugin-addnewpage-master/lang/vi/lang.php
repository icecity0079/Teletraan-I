<?php
/*
 * Vietnamese language file
 */
$lang['namespaceRoot'] = "Gốc";
$lang['okbutton']      = "Tạo trang mới";
$lang['nooption']      = "Bạn không được phép tạo trang mới";
//Setup VIM: ex: et ts=2 enc=utf-8 :
