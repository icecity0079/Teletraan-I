<?php
/*USE : UTF8*/

/*
 * Vietnamese language file
 */
$lang['addpage_exclude']  = "Bỏ tên miền (ngăn cách bằng dấu ;)";
$lang['addpage_showroot'] = "Hiển thị tên miền gốc";
$lang['addpage_hide']     = "Khi bạn chọn syntax {{NEWPAGE>[ns]}}: Ẩn khả năng lựa chọn tên miền (không chọn: chỉ hiển thị tên miền phụ)";
$lang['addpage_hideACL']  = "Ẩn {{NEWPAGE}} nếu người dùng không được phép tạo trang mới (hiển thị tin nhắn nếu không chọn)";
