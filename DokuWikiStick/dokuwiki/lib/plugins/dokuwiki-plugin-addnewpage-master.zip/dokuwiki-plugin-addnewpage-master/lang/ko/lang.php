<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['namespaceRoot']         = '루트';
$lang['okbutton']              = '문서 추가';
$lang['nooption']              = '문서를 추가할 권한이 없습니다';
