<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Arne Hanssen <arne.hanssen@getmail.no>
 */
$lang['addpage_exclude']       = 'Utelatte navnerom (separert med ;)';
$lang['addpage_showroot']      = 'Vis rot-navnerom';
$lang['addpage_hide']          = 'Når du bruker {{NEWPAGE>[ns]}} syntaks: skjul valg av navnerom (ikke avhuket: vis bare undernavnerom)';
$lang['addpage_hideACL']       = 'Skjul {NEWPAGE}} dersom bruker ikke har tilgang til å legge til sider (ikke avhuket: vis tilbakemelding) ';
