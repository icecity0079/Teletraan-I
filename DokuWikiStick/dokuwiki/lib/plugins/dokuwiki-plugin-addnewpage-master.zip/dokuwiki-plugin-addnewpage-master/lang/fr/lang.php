<?php
/*USE : UTF8*/
/*
 * French language file
 */
$lang['namespaceRoot'] = "Racine";
$lang['okbutton']      = "Cr&eacute;er";
$lang['nooption']      = "Vous n'avez pas les droits pour ajouter une page";
