<?php
/*USE : UTF8*/

/*
 * Chinese (Simplified) language file
 */
$lang['addpage_exclude']  = "排除的命名空间(使用；来分隔命名空间)";
$lang['addpage_showroot'] = "显示根部命名空间";
$lang['addpage_hide']     = "在使用 {{NEWPAGE>[ns]}} 时不显示命名空间的选择（未勾选则仅显示子命名空间）";
$lang['addpage_hideACL']  = "用户没有新增页面权限时隐藏{{NEWPAGE}}（若未勾选则显示信息）";
