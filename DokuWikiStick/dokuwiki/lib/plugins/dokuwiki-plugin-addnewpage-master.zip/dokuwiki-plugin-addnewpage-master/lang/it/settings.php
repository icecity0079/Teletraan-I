<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Mirko <malisan.mirko@gmail.com>
 */
$lang['addpage_hideACL']       = 'Nascondi {{NEWPAGE}} se l\'utente non &egrave autorizzato ad aggiungere pagine(mostra il messaggio se non &egrave selezionato)';
