<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Robert Bogenschneider <bogi@uea.org>
 */
$lang['namespaceRoot']         = 'Bazo';
$lang['okbutton']              = 'Aldoni paĝon';
$lang['nooption']              = 'Vi ne rajtas aldoni paĝojn';
