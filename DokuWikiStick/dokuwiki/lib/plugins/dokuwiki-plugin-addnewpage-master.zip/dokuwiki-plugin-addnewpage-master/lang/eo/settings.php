<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Robert Bogenschneider <bogi@uea.org>
 */
$lang['addpage_exclude']       = 'Ekskludi nomspacojn (disigitaj per ;)';
$lang['addpage_showroot']      = 'Montri nomspacon';
$lang['addpage_hide']          = 'Se vi uzas {{NEWPAGE>[ns]}}-sintakson: Ĉu kaŝi la nomspac-selekton? (malplena: montri nur subnomspacojn)';
$lang['addpage_hideACL']       = 'Kaŝi {{NEWPAGE}} se uzanto ne rajtas aldoni paĝojn (montri mesaĝon, se malplena)';
