<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Samory Pereira Santos <samory.santos@gmail.com>
 */
$lang['addpage_exclude']       = 'Excluir namespaces (separar com ;)';
$lang['addpage_showroot']      = 'Mostrar namespace raiz';
