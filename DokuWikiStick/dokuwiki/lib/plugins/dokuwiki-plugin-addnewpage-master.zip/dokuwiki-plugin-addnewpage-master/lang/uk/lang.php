<?php
/*
 * Ukrainian language file
 */
$lang['encoding']      = 'utf-8';
$lang['direction']     = 'ltr';
$lang['namespaceRoot'] = 'Кореневий простір імен';
$lang['okbutton']      = 'Додати сторінку';
//Setup VIM: ex: et ts=2 enc=utf-8 :
