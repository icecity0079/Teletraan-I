<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Ali Almlfy <Almlfy@hotmail.com>
 */
$lang['addpage_exclude']       = 'النطقات المسثناة (يفصل بينها بـ ;)';
$lang['addpage_showroot']      = 'اعرض نطاق الجذر';
$lang['addpage_hide']          = 'عند استعمال صيغة {{صفحة جديدة>[ns]}}: أخفي اختيار تسمية النطاق (وإلا فإنه سيظهر النطاق الفرعية)';
$lang['addpage_hideACL']       = 'اخفاء {{صفحة جديد}} إن لم يكن للمستخدم الحق في إضافة صفحات (وإلا فإنها ستظهر)';
