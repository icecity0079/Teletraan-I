<?php
/**
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */

$lang['no_results']   = '検索照会の結果がありません：« %1s »';
$lang['jump_section'] = '上の « %1$s » セクションに続きます...'; // '%1$s' は該当見出しで置換されます
$lang['jump_to_top']  = 'このページ一覧の先頭に戻る';
$lang['link_to_top']  = '先頭 ↑';
$lang['regex_error']  = '正規表現にエラーがあります。確認してやり直してください。';
$lang['empty_filter'] = 'フィルター式は、結果なしを返しました。';
